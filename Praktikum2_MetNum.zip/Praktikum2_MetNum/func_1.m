function func_1(a)
  fprintf("Nama saya adalah %s\n", a)
  callname(a)
end

function callname (a)
  fprintf("Kata \"%s\" diawali dengan huruf %c.\n", a, a(1))
end
