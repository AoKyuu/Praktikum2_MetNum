function result = func_2 (a)
  result = 2*a;
end
