function result = func_5(a)
  result = 0;
  return
  result = a*2;
end
