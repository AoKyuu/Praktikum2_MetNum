function func(a)
  fprintf("Nama saya %s!\n", a)
end

