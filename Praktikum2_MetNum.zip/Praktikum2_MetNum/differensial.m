fprintf("Differensial & Integral\n\n");

pkg load symbolic
syms x

fprintf("Differensial\n\n");

a = input("Masukkan bentuk persamaan f(x) = ");
a_asli = sym(a)
a_turunan = diff(a_asli, "x")

fprintf("\nIntegral\n\n");

a = input("Masukkan bentuk persamaan f(x) = ");
a_asli = sym(a)
a_integral = int(a_asli, "x")
