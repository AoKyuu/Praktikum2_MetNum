fprintf("Looping\n\n");

fprintf("For Loop\n");
for i = 1:5
    a = i^1/2;
    fprintf("P = %.1f\n", a);
end

fprintf("\nWhile Loop\n");
a = 5
while (a <= 10)
  b = a^2
  a = a + 1;
end

fprintf("\nContinue\n");
for i = 5:10
  if (i==11)
    continue
  end
  a = i^2
end

fprintf("\nBreak\n");
for i = 5:10
  if (i==11)
    break
  end
  a = i^2
end

