function [kali1, kali2] = func_3 (a1, a2)
  kali1 = a1*1
  kali2 = a2*2
end
